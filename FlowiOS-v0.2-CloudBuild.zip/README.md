# FlowiOS v0.2 — Cloud-buildable iOS starter

This is an independently written native SwiftUI starter inspired by a modern video/music discovery app. It is not a direct port of Flow's Android source.

## No Mac? Use GitHub Actions
1. Create a new **public or private** GitHub repository.
2. Upload the contents of this folder (including `.github` and `FlowiOS.xcodeproj`).
3. Open the repository's **Actions** tab.
4. Run **Build iOS Simulator App** (or push a commit).
5. Download the `FlowiOS-Simulator-Build` artifact from the workflow run.

GitHub-hosted macOS runners run Xcode for you. The artifact is a simulator `.app`, not an installable App Store IPA. Installing on a physical iPhone or publishing requires Apple signing/provisioning and an Apple Developer account; a Mac is not strictly required if signing/building is handled in a suitable cloud CI service.

## Open locally
Open `FlowiOS.xcodeproj` in Xcode 16+; deployment target iOS 17+.

## Implemented in this starter
- Native dark SwiftUI tab navigation
- Discovery feed, category chips, search
- Video detail screen with AVPlayer when an authorized playback URL exists
- Saved library with local persistence using UserDefaults
- Settings screen and playback preference placeholders
- Audio session setup for playback
- GitHub Actions cloud build workflow

## Important feature boundaries
This is a foundation, not a finished YouTube replacement. No live YouTube feed, account login, recommendation service, SponsorBlock, Shorts ingestion, or download pipeline is connected yet. These require a compliant content source and backend/API design. Do not scrape private endpoints or bypass access controls. Background audio/PiP behavior must be validated on real iOS devices and requires the appropriate app capabilities and media source.

## Licensing
No Flow Android source files are copied into this starter. If you later adapt GPL-3.0 code from Flow, comply with its license obligations before distributing the resulting app.
