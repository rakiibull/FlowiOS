import SwiftUI

@main
struct FlowiOSApp: App {
    @StateObject private var library = LibraryStore()

    init() {
        PlaybackAudioSession.configure()
    }

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(library)
                .preferredColorScheme(.dark)
        }
    }
}
