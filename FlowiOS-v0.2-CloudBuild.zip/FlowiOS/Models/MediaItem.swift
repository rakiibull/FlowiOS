import Foundation

struct MediaItem: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let creator: String
    let duration: String
    let artworkURL: URL?
    let playbackURL: URL?

    static let samples: [MediaItem] = [
        .init(id: "sample-1", title: "Explore the world", creator: "Sample Channel", duration: "12:48", artworkURL: nil, playbackURL: nil),
        .init(id: "sample-2", title: "Focus music — calm mix", creator: "Sample Music", duration: "1:02:15", artworkURL: nil, playbackURL: nil),
        .init(id: "sample-3", title: "iOS development basics", creator: "Developer Studio", duration: "18:06", artworkURL: nil, playbackURL: nil),
        .init(id: "sample-4", title: "A quiet evening playlist", creator: "Flow Sounds", duration: "42:10", artworkURL: nil, playbackURL: nil)
    ]
}
