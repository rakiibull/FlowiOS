import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var library: LibraryStore
    @State private var quality = "Auto"
    @State private var backgroundAudio = true

    var body: some View {
        NavigationStack {
            Form {
                Section("Playback") {
                    Picker("Video quality", selection: $quality) {
                        Text("Auto").tag("Auto")
                        Text("1080p").tag("1080p")
                        Text("720p").tag("720p")
                        Text("480p").tag("480p")
                    }
                    Toggle("Background audio preference", isOn: $backgroundAudio)
                    Text("This preference is a UI setting; actual background playback depends on a supported media source and iOS capabilities.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Privacy & data") {
                    Label("Recommendations stored locally", systemImage: "brain")
                    Button("Clear watch history", role: .destructive) { library.clearHistory() }
                }
                Section("About") {
                    HStack { Text("App"); Spacer(); Text("FlowiOS").foregroundStyle(.secondary) }
                    HStack { Text("Version"); Spacer(); Text("0.2.0").foregroundStyle(.secondary) }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Settings")
        }
    }
}
