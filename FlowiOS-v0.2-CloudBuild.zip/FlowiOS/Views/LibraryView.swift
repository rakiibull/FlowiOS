import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @State private var selectedSection = "Saved"

    var items: [MediaItem] { selectedSection == "Saved" ? library.savedItems : library.history }

    var body: some View {
        NavigationStack {
            VStack {
                Picker("Library", selection: $selectedSection) {
                    Text("Saved").tag("Saved")
                    Text("History").tag("History")
                }.pickerStyle(.segmented).padding()
                if items.isEmpty {
                    ContentUnavailableView(selectedSection == "Saved" ? "Nothing saved yet" : "No watch history",
                        systemImage: selectedSection == "Saved" ? "bookmark" : "clock",
                        description: Text("Your items will appear here."))
                } else {
                    List(items) { item in
                        NavigationLink(value: item) {
                            VStack(alignment: .leading) {
                                Text(item.title).foregroundStyle(.primary)
                                Text(item.creator).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }.scrollContentBackground(.hidden)
                }
                Spacer(minLength: 0)
            }
            .background(Color.black)
            .navigationTitle("Your library")
            .navigationDestination(for: MediaItem.self) { PlayerView(item: $0) }
        }
    }
}
