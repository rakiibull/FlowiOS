import SwiftUI

struct SearchView: View {
    @State private var query = ""
    private var results: [MediaItem] {
        guard !query.isEmpty else { return MediaItem.samples }
        return MediaItem.samples.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.creator.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Search videos and music", text: $query)
                        .textInputAutocapitalization(.never)
                }
                .padding(14).background(Color.white.opacity(0.10)).clipShape(RoundedRectangle(cornerRadius: 14))
                ScrollView {
                    LazyVStack(spacing: 18) {
                        ForEach(results) { item in
                            NavigationLink(value: item) { MediaCard(item: item) }.buttonStyle(.plain)
                        }
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.top)
            .background(Color.black)
            .navigationTitle("Search")
            .navigationDestination(for: MediaItem.self) { PlayerView(item: $0) }
        }
    }
}
