import SwiftUI
import AVKit

struct PlayerView: View {
    let item: MediaItem
    @EnvironmentObject private var library: LibraryStore
    @State private var player: AVPlayer?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Group {
                    if let player {
                        VideoPlayer(player: player).frame(height: 235)
                    } else {
                        RoundedRectangle(cornerRadius: 18).fill(Color(white: 0.14))
                            .overlay {
                                VStack(spacing: 10) {
                                    Image(systemName: "play.circle.fill").font(.system(size: 54))
                                    Text("Playback source not connected")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                            }.frame(height: 235)
                    }
                }
                Text(item.title).font(.title3.bold())
                Text(item.creator).foregroundStyle(.secondary)
                HStack {
                    Label("Like", systemImage: "hand.thumbsup")
                    Spacer()
                    Button {
                        library.toggleSaved(item)
                    } label: {
                        Label(library.contains(item) ? "Saved" : "Save",
                              systemImage: library.contains(item) ? "bookmark.fill" : "bookmark")
                    }
                }.buttonStyle(.bordered).tint(.white)
                Text("Playback requires a valid, authorized media URL from your content provider.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding()
        }
        .background(Color.black)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            library.recordPlayed(item)
            if let url = item.playbackURL { player = AVPlayer(url: url) }
        }
        .onDisappear { player?.pause() }
    }
}
