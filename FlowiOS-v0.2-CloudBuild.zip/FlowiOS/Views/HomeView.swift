import SwiftUI

struct HomeView: View {
    @State private var selectedFilter = "For you"
    private let filters = ["For you", "Music", "Gaming", "Learning", "Live"]

    var body: some View {
        NavigationStack {
            ScrollView {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(filters, id: \.self) { filter in
                            Button(filter) { selectedFilter = filter }
                                .font(.subheadline.weight(.semibold))
                                .padding(.horizontal, 15).padding(.vertical, 9)
                                .background(selectedFilter == filter ? .white : Color.white.opacity(0.10))
                                .foregroundStyle(selectedFilter == filter ? .black : .white)
                                .clipShape(Capsule())
                        }
                    }.padding(.horizontal)
                }
                LazyVStack(spacing: 22) {
                    ForEach(MediaItem.samples) { item in
                        NavigationLink(value: item) { MediaCard(item: item) }
                            .buttonStyle(.plain)
                    }
                }.padding(.top, 18)
            }
            .background(Color.black)
            .navigationTitle("Discover")
            .navigationDestination(for: MediaItem.self) { item in PlayerView(item: item) }
        }
    }
}

struct MediaCard: View {
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(Color(white: 0.15))
                Image(systemName: "play.rectangle.fill")
                    .font(.system(size: 48)).foregroundStyle(.white.opacity(0.8))
                Text(item.duration).font(.caption2.bold()).padding(5)
                    .background(.black.opacity(0.8)).clipShape(RoundedRectangle(cornerRadius: 5))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing).padding(10)
            }.frame(height: 205)
            HStack(alignment: .top, spacing: 12) {
                Circle().fill(Color.white.opacity(0.16)).frame(width: 38, height: 38)
                    .overlay(Image(systemName: "person.fill").foregroundStyle(.white.opacity(0.8)))
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title).font(.headline).foregroundStyle(.white)
                    Text(item.creator).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "ellipsis").foregroundStyle(.secondary)
            }
        }.padding(.horizontal)
    }
}
