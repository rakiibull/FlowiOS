import AVFoundation

enum PlaybackAudioSession {
    static func configure() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            // Playback can still work while the app is foregrounded.
            print("Audio session configuration failed: \(error.localizedDescription)")
        }
    }
}
