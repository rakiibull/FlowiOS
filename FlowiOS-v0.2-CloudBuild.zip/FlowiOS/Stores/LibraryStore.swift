import Foundation
import Combine

@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var savedItems: [MediaItem] = []
    @Published private(set) var history: [MediaItem] = []

    private let savedKey = "flowios.saved.v1"
    private let historyKey = "flowios.history.v1"

    init() {
        savedItems = load(savedKey)
        history = load(historyKey)
    }

    func contains(_ item: MediaItem) -> Bool { savedItems.contains(item) }

    func toggleSaved(_ item: MediaItem) {
        if contains(item) {
            savedItems.removeAll { $0.id == item.id }
        } else {
            savedItems.insert(item, at: 0)
        }
        persist(savedItems, key: savedKey)
    }

    func recordPlayed(_ item: MediaItem) {
        history.removeAll { $0.id == item.id }
        history.insert(item, at: 0)
        history = Array(history.prefix(100))
        persist(history, key: historyKey)
    }

    func clearHistory() {
        history = []
        UserDefaults.standard.removeObject(forKey: historyKey)
    }

    private func load(_ key: String) -> [MediaItem] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([MediaItem].self, from: data) else { return [] }
        return decoded
    }

    private func persist(_ items: [MediaItem], key: String) {
        guard let data = try? JSONEncoder().encode(items) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
